/* 
 * File:   HdwrTest.h
 * Author: Norman McFarland
 *
 * Created on January 17, 2017, 4:52 PM
 */

#ifndef HDWRTEST_H
#define	HDWRTEST_H

#ifdef	__cplusplus
extern "C" {
#endif

void HdwrTest(void) ;


#ifdef	__cplusplus
}
#endif

#endif	/* HDWRTEST_H */

