/* 
 * File:   multiMotorDrivers.h
 * Author: Norman McFarland
 *
 * Created on March 20, 2017, 11:34 AM
 */

#ifndef MULTIMOTORDRIVERS_H
#define	MULTIMOTORDRIVERS_H

#ifdef	__cplusplus
extern "C" {
#endif

    int multiMotorMove(position, speed, motor)  ;


#ifdef	__cplusplus
}
#endif

#endif	/* MULTIMOTORDRIVERS_H */

