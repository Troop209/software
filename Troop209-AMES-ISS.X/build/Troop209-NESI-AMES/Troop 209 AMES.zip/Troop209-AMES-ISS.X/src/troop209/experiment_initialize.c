#include "experiment_initialize.h"
#include "SD_support.h"

SDConfig config;

void initialize_experiment(void) {
    SDConfig SDConfigFile.get(&config);
    // read configuration file
    // read external rtc
    // update internal rtc
    // check temperature
    // if temp > 50
    // wait (x)
}