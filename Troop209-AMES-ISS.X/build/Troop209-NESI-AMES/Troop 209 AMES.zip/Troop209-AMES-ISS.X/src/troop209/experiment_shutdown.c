#include "experiment_shutdown.h"

void shutdown_experiment() {
    usb.connect();
}
