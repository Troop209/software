#ifndef EXPERIMENT_SHUTDOWN_H
#define EXPERIMENT_SHUTDOWN_H
#include "usb.h"

/**
 * Shutdown experiment
 */

void shutdown_experiment(void) ;


#endif /* EXPERIMENT_SHUTDOWN_H */
