#ifndef EXPERIMENT_INITIALIZE_H
#define EXPERIMENT_INITIALIZE_H


void initialize_experiment(void) ;

#endif 
